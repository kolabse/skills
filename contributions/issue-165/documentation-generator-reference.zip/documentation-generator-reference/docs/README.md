# Пример документации

Синтетический набор для адаптации renderer. Реальных систем и доступов здесь нет.

- [Обзор](overview/README.md)
- [Общие инструкции](technical/general/README.md)
- [Эксплуатация](technical/internal/README.md)
- [Стандарты](standards/README.md)
