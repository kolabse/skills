# Reference source for revision-bound documentation generation

This contribution preserves an existing Markdown-to-static-site pipeline as a reviewable reference implementation. It is source material for a future portable skill, not a scaffolded skill and not a claim of production readiness. The contributor approved redistribution of original material under Apache-2.0; see LICENSE and NOTICE.md.

## Included capabilities

- Canonical tracked Markdown remains in Git; generated pages and packages are separate.
- MkDocs hooks retain source revision, update dates, direction/type metadata, approved revision-bound links and optional legacy redirects.
- Local frontend dependencies provide search, Unicode headings, tables, syntax highlighting, exact text copying and Mermaid diagrams.
- The builder requires a clean committed checkout, rejects a changed Git state, inspects output links and anchors, and packages files with per-file SHA-256 in a source-bound manifest.
- Synthetic Markdown and unit fixtures contain no real project documentation.

## Layout and configuration before use

Keep scripts/ and web/docs-site/ beneath a consumer Git root. The current reference expects docs/, four example direction prefixes, GitLab-style source links, Python and Node/npm. Configure the reserved example domains, branding and taxonomy before any real publication; there is no fallback to the originating repository. The default source allowlist is empty. The optional path-map.json contains no original redirect records.

Do not add credentials, state, private input files or real source allowlists to this reference. Configure access control outside the renderer. Noindex and an internal-audience label are not authentication. Markdown authors and raw HTML are trusted inputs in this implementation.

## Runtime prerequisites for a later cloud check

Prepare Git, Python 3.12 and Node 22.20.x with npm in the approved cloud job. Node 22.20.x matches the retained dependency range, including a native dependency requiring ^22.20, ^24.12 or >=25; older Node 22 minors are insufficient. These are declared check prerequisites, not evidence that this extracted package was executed. Do not install tools or dependencies on a workstation for this handoff.

## Review and validation

No local tests, renderer, npm, MkDocs, dependency installation or website publication were run while preparing this package. The extracted and modified package has not been executed in its own cloud pipeline. Existing source validation does not prove this extraction works unchanged.

For a later authorized cloud check in a disposable committed Git repository, keep the synthetic docs tracked and use the consumer's approved build job. The reference build entry point is scripts/build_documentation.py. The synthetic focused suite is scripts/tests/test_documentation_site.py. Do not infer permission to run them on a workstation. No CI workflow or deployment credentials are bundled.

Before public deployment, independently validate dependency installation, the build, browser behavior, privacy review and the consumer's access controls in the allowed environment. A website release is a separate action from source acceptance.

## Known limitations and next implementation work

1. Consumer paths, taxonomy, locale, branding and provider routes need a versioned configuration contract; the reference still shows a fixed example layout.
2. Link rewriting uses regular expressions, not a Markdown syntax tree. Complex fences and unusual links require further fixtures.
3. Output checks inspect HTML href/src and selected text types; they do not sanitize arbitrary HTML or cover every CSS, JavaScript, srcset or form destination.
4. Secret detection is heuristic. Symlink-directory and broken-symlink handling need review. Neither check proves that content is safe for disclosure.
5. Git filename parsing needs NUL-safe handling for unusual and quoted Unicode filenames; revision syntax and provider URL encoding need explicit validation.
6. Requirements are version-pinned without pip hashes. Cache fingerprints need runtime/platform identity. The archive is not reproducible bit for bit.
7. Fresh build date, technical verification date, content update and approval state need independent metadata; a build does not establish runtime acceptance.
8. The code provides no deployment, authentication, RBAC, monitoring or service recovery. Preserve those boundaries during a future skill implementation.

## Excluded material

No original documentation, organization identity, internal addresses, original source whitelist or redirect map, generated site, packaged dependencies, fonts, icons, runtime manifests, access profiles, deployment helpers, monitoring definitions or runner configuration is included.
