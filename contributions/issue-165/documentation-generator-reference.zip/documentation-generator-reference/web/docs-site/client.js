import '@fontsource/inter/latin-400.css';
import '@fontsource/inter/cyrillic-400.css';
import '@fontsource/inter/latin-600.css';
import '@fontsource/inter/cyrillic-600.css';
import '@fontsource/inter/latin-700.css';
import '@fontsource/inter/cyrillic-700.css';
import hljs from 'highlight.js/lib/core';
import yaml from 'highlight.js/lib/languages/yaml';
import bash from 'highlight.js/lib/languages/bash';
import powershell from 'highlight.js/lib/languages/powershell';
import json from 'highlight.js/lib/languages/json';
import python from 'highlight.js/lib/languages/python';
import './site.css';
for (const [name, definition] of Object.entries({yaml,bash,powershell,json,python})) hljs.registerLanguage(name,definition);
const base = new URL('.', new URL(document.querySelector('meta[name="docs-base"]').content, location.href)).href;
for (const table of document.querySelectorAll('.article-body table')) {
  const wrapper = document.createElement('div'); wrapper.className='table-scroll'; wrapper.tabIndex=0;
  wrapper.setAttribute('role','region'); wrapper.setAttribute('aria-label','Таблица документа');
  table.before(wrapper); wrapper.append(table);
}
for (const pre of document.querySelectorAll('.article-body pre:not(.mermaid)')) {
  const code=pre.querySelector('code'); if (!code) continue;
  const content=code.textContent; const language=(code.className.match(/language-([\w-]+)/)||[])[1]||'text';
  if (hljs.getLanguage(language)) { code.innerHTML=hljs.highlight(content,{language}).value; }
  const wrapper=document.createElement('div'); wrapper.className='code-block'+(['bash','shell','powershell','console'].includes(language)?' terminal':'');
  const heading=document.createElement('div'); heading.className='code-heading';
  const label=document.createElement('span'); label.textContent=language+' · '+(wrapper.classList.contains('terminal')?'Команда / вывод':'Код');
  const copy=document.createElement('button'); copy.type='button'; copy.textContent='Копировать'; copy.setAttribute('aria-label','Копировать блок '+language);
  const status=document.createElement('span'); status.className='sr-only'; status.setAttribute('role','status');
  copy.addEventListener('click',async()=>{ try { await navigator.clipboard.writeText(content); copy.textContent='Скопировано'; status.textContent='Скопировано'; }
    catch { status.textContent='Не удалось скопировать. Выделите текст вручную.'; }
    setTimeout(()=>{copy.textContent='Копировать';status.textContent='';},3500); });
  heading.append(label,copy); pre.before(wrapper); wrapper.append(heading,pre,status);
}
const diagrams=document.querySelectorAll('pre.mermaid,div.mermaid');
if (diagrams.length) {
  import('mermaid').then(({default:mermaid})=>{
    mermaid.initialize({startOnLoad:false,securityLevel:'strict',theme:'base',fontFamily:'Inter, sans-serif',flowchart:{htmlLabels:false}});
    for (const diagram of diagrams) { const code=diagram.querySelector('code'); if(code) diagram.textContent=code.textContent; }
    return mermaid.run({nodes:diagrams}).then(()=>{
      for(const svg of document.querySelectorAll('.mermaid svg')) {
        // Retain the diagram's readable scale; scroll large graphs inside the article.
        const width=svg.viewBox.baseVal.width; if(width>0)svg.style.width=Math.max(600,width)+'px';
      }
    });
  }).catch(()=>{ for(const diagram of diagrams) {const message=document.createElement('p');message.textContent='Схема не отобразилась. Ниже доступен её исходный текст.';diagram.before(message);} });
}
const search=document.querySelector('.search input'),results=document.querySelector('.search-results');
let indexPromise;
async function runSearch() {
  const query=search.value.trim().toLocaleLowerCase('ru'); results.replaceChildren(); results.hidden=!query;
  if(!query)return;
  indexPromise ||= fetch(base+'search/search_index.json').then(response=>{if(!response.ok)throw Error('search');return response.json();});
  try {const index=await indexPromise;if(query!==search.value.trim().toLocaleLowerCase('ru'))return;
    const words=query.split(/\s+/);
    const titleScore=doc=>words.filter(word=>doc.title.toLocaleLowerCase('ru').includes(word)).length;
    const hits=index.docs.filter(doc=>words.every(word=>(doc.title+' '+doc.text).toLocaleLowerCase('ru').includes(word)))
      .sort((a,b)=>titleScore(b)-titleScore(a)||Number(a.location.includes('#'))-Number(b.location.includes('#'))).slice(0,12);
    const status=document.createElement('p');status.className='search-summary';status.setAttribute('role','status');status.textContent=hits.length?'Результаты поиска':'Документы не найдены';results.append(status);
    for(const hit of hits){const link=document.createElement('a');link.href=base+hit.location;link.textContent=hit.title;results.append(link);}
  }catch{results.textContent='Поиск недоступен. Используйте разделы документации.';}
}
search.addEventListener('input',runSearch);
search.addEventListener('keydown',event=>{if(event.key==='Escape')results.hidden=true;if(event.key==='Enter'){event.preventDefault();results.querySelector('a')?.click();}});
document.addEventListener('click',event=>{if(!event.target.closest('.search'))results.hidden=true;});
const observer=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting){for(const link of document.querySelectorAll('.contents a')){
  if(decodeURIComponent(link.hash.slice(1))===entry.target.id)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');
}}},{rootMargin:'-10% 0px -65% 0px'});
for(const heading of document.querySelectorAll('.article-body h2[id],.article-body h3[id],.article-body h4[id]')) observer.observe(heading);
