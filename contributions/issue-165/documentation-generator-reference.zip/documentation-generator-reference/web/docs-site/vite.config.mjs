import { defineConfig } from 'vite';
import { readFileSync, writeFileSync, copyFileSync } from 'node:fs';
export default defineConfig({
  build: {
    outDir: 'theme/assets', emptyOutDir: true,
    lib: { entry: 'client.js', formats: ['es'], fileName: () => 'client.js', cssFileName: 'style' },
  },
  plugins: [{ name: 'theme-assets', closeBundle() {
    writeFileSync('theme/assets/layout.css', readFileSync('layout.css'));
    for (const icon of ['lock', 'search', 'copy', 'check'])
      copyFileSync(`node_modules/@tabler/icons/icons/outline/${icon}.svg`, `theme/assets/${icon}.svg`);
  }}],
});
