"""MkDocs hooks: publish tracked docs only, bind sources and metadata to Git."""
import datetime
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.documentation_site import direction, resolve_link

LABELS = {'overview': 'Об инфраструктуре', 'general': 'Общая техническая',
          'internal': 'Внутренняя техническая', 'standards': 'Стандарты и требования'}
SECTIONS = {'operations': 'Эксплуатация', 'architecture': 'Архитектура',
            'guides': 'Инструкции', 'automation': 'Автоматизация',
            'migration': 'Миграция', 'reports': 'Отчёты', 'standards': 'Документация'}
state = {}


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True, encoding='utf-8').strip()


def on_config(config):
    state.clear()
    state['revision'] = git('rev-parse', 'HEAD')
    state['tracked'] = set(git('ls-files', 'docs').splitlines())
    state['allowed'] = set(json.loads((ROOT / 'web/docs-site/source-links.json').read_text(encoding='utf-8'))['paths'])
    state['dates'] = {}
    date = ''
    for line in git('log', '--format=DATE:%cs', '--name-only', '--', 'docs').splitlines():
        if line.startswith('DATE:'):
            date = line[5:]
        elif line.startswith('docs/'):
            state['dates'].setdefault(line[5:], date)
    redirect_file = ROOT / 'web/docs-site/path-map.json'
    state['legacy'] = json.loads(redirect_file.read_text(encoding='utf-8'))['documents'] if redirect_file.exists() else []
    return config


def on_files(files, config):
    for file in list(files):
        if file.src_dir == config['docs_dir'] and Path(file.abs_src_path).is_symlink():
            raise ValueError('Documentation source symlinks are forbidden')
        if file.src_dir == config['docs_dir'] and (
            'docs/' + file.src_uri not in state['tracked'] or not file.src_uri.endswith('.md')
        ):
            files.remove(file)
    return files


def on_page_markdown(markdown, page, config, files):
    # Preserve commands and code fences. Rewrite only Markdown link destinations.
    blocks = re.split(r'(^```[^\n]*\n.*?^```[^\n]*$|^~~~[^\n]*\n.*?^~~~[^\n]*$)', markdown, flags=re.M | re.S)
    def replace(match):
        target = match.group(2).strip('<>')
        mapped = resolve_link(page.file.src_uri, target, ROOT, state['allowed'], state['revision'])
        return match.group(1) + mapped + match.group(3)
    for index in range(0, len(blocks), 2):
        blocks[index] = re.sub(r'(\]\()(<?[^\s)]+>?)([^)]*\))', replace, blocks[index])
        blocks[index] = re.sub(r'(^\[[^\]]+\]:\s*)(\S+)(.*$)', replace, blocks[index], flags=re.M)
    return ''.join(blocks)


def on_page_context(context, page, config, nav):
    key = direction(page.file.src_uri)
    parent = Path(page.file.src_uri).parent
    section = SECTIONS.get(parent.name, LABELS[key])
    direction_uri = {'overview': 'overview/index.html', 'general': 'technical/general/index.html',
                     'internal': 'technical/internal/index.html', 'standards': 'standards/index.html'}[key]
    context['direction_uri'] = direction_uri
    context['section_uri'] = (parent / 'index.html').as_posix() if 'docs/' + (parent / 'README.md').as_posix() in state['tracked'] else direction_uri
    context['direction'] = key
    context['direction_label'] = LABELS[key]
    context['section_label'] = section
    default_type = ('Обзор' if page.file.src_uri.endswith('README.md') else 'Стандарт' if key == 'standards'
                    else 'Инструкция' if parent.name in {'operations', 'guides'} else 'Отчёт' if parent.name == 'reports'
                    else 'Архитектурное решение' if parent.name == 'architecture' and Path(page.file.src_uri).name.startswith('0001-') else 'Справочник')
    context['document_type'] = page.meta.get('document_type', default_type)
    if context['document_type'] not in {'Обзор', 'Инструкция', 'Справочник', 'Архитектурное решение', 'Стандарт', 'Отчёт'}:
        raise ValueError('Unknown document_type metadata')
    context['updated'] = state['dates'].get(page.file.src_uri, '')
    context['revision'] = state['revision']
    context['directions'] = [(value, LABELS[value], uri) for value, uri in [
        ('overview', 'overview/index.html'), ('general', 'technical/general/index.html'),
        ('internal', 'technical/internal/index.html'), ('standards', 'standards/index.html')]]
    return context


def on_page_content(html, page, config, files):
    # The page title has its own semantic h1 in the selected template.
    first = re.match(r'^<h1\b[^>]*id="([^"]+)"', html)
    page.meta['title_anchor'] = first.group(1) if first else 'page-title'
    html = re.sub(r'^<h1\b[^>]*>.*?</h1>\s*', '', html, count=1, flags=re.S)
    html = re.sub(r'(<a\s[^>]*href="https://git\.example\.invalid/group/documentation/-/(?:blob|tree)/[^"]+"[^>]*>.*?</a>)',
                  r'\1 <span class="source-note">(GitLab · требуется учётная запись)</span>', html, flags=re.S)
    return html


def on_post_build(config):
    import html
    import posixpath
    output = Path(config['site_dir'])
    def html_uri(path):
        path = path.removeprefix('docs/')
        return str(Path(path).with_suffix('.html')).replace('\\', '/').replace('README.html', 'index.html')
    for item in state['legacy']:
        source, target = html_uri(item['source']), html_uri(item['current'])
        if source == target:
            continue
        alias, destination = (output / source).resolve(), (output / target).resolve()
        if not alias.is_relative_to(output.resolve()) or not destination.is_file():
            raise ValueError('Invalid documentation redirect')
        if alias.exists():
            raise ValueError(f'Redirect collides with current output: {source}')
        uri = posixpath.relpath(target, posixpath.dirname(source) or '.')
        alias.parent.mkdir(parents=True, exist_ok=True)
        alias.write_text('<!doctype html><html lang="ru"><head><meta charset="utf-8">'
                         '<meta name="robots" content="noindex,nofollow">'
                         f'<meta http-equiv="refresh" content="0;url={html.escape(uri, quote=True)}">'
                         '</head><body>Только для внутреннего использования. '
                         f'<a href="{html.escape(uri, quote=True)}">Открыть актуальный документ</a>'
                         '</body></html>', encoding='utf-8')
