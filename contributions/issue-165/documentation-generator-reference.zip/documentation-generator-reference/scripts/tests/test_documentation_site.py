import tempfile
import unittest
import json
from pathlib import Path
from scripts.documentation_site import direction, resolve_link, validate_output


class DocumentationSiteTests(unittest.TestCase):
    def test_output_rejects_secret_file(self):
        with tempfile.TemporaryDirectory() as temp:
            (Path(temp) / '.env').write_text('private', encoding='utf-8')
            with self.assertRaises(ValueError):
                validate_output(temp)

    def test_output_rejects_missing_local_asset(self):
        with tempfile.TemporaryDirectory() as temp:
            (Path(temp) / 'index.html').write_text('<script src="missing.js"></script>', encoding='utf-8')
            with self.assertRaises(ValueError):
                validate_output(temp)

    def test_output_rejects_private_key_in_html(self):
        with tempfile.TemporaryDirectory() as temp:
            (Path(temp) / 'index.html').write_text('-----BEGIN PRIVATE KEY-----', encoding='utf-8')
            with self.assertRaises(ValueError):
                validate_output(temp)

    def test_machine_file_in_docs_requires_approved_gitlab_source_link(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'docs').mkdir()
            (root / 'docs/map.json').write_text('{}', encoding='utf-8')
            result = resolve_link('README.md', 'map.json', root, {'docs/map.json'}, 'a' * 40)
            self.assertIn('/-/blob/' + 'a' * 40 + '/docs/map.json', result)

    def test_unapproved_machine_file_in_docs_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'docs').mkdir()
            (root / 'docs/map.json').write_text('{}', encoding='utf-8')
            with self.assertRaises(ValueError):
                resolve_link('README.md', 'map.json', root, set(), 'a' * 40)

    def test_general_direction_does_not_grant_external_access(self):
        self.assertEqual(direction('technical/general/guide.md'), 'general')

    def test_external_source_requires_explicit_allowlist(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'docs').mkdir()
            (root / 'inventory').mkdir()
            (root / 'inventory/services.yaml').write_text('data', encoding='utf-8')
            with self.assertRaises(ValueError):
                resolve_link('README.md', '../inventory/services.yaml', root, set(), 'a' * 40)

    def test_allowed_source_becomes_revision_bound_gitlab_link(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'docs').mkdir()
            (root / 'inventory').mkdir()
            (root / 'inventory/services.yaml').write_text('data', encoding='utf-8')
            result = resolve_link('README.md', '../inventory/services.yaml', root,
                                  {'inventory/services.yaml'}, 'a' * 40)
            self.assertIn('/-/blob/' + 'a' * 40 + '/inventory/services.yaml', result)

    def test_secret_target_is_rejected_even_if_allowlisted(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'docs').mkdir()
            (root / '.secrets').mkdir()
            (root / '.secrets/password').write_text('private', encoding='utf-8')
            with self.assertRaises(ValueError):
                resolve_link('README.md', '../.secrets/password', root,
                             {'.secrets/password'}, 'a' * 40)

    def test_path_outside_repository_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'docs').mkdir()
            with self.assertRaises(ValueError):
                resolve_link('README.md', '../../outside.txt', root, set(), 'a' * 40)


if __name__ == '__main__':
    unittest.main()
