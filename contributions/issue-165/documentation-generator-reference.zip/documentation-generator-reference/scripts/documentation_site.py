"""Boundaries and metadata for the internal documentation build."""
from pathlib import Path
from html.parser import HTMLParser
from functools import lru_cache
import re
from urllib.parse import quote, unquote, urlsplit

REPOSITORY_URL = 'https://git.example.invalid/group/documentation'


def validate_output(output):
    output = Path(output).resolve()
    files = sorted(path for path in output.rglob('*') if path.is_file())
    allowed_extensions = {'.html', '.js', '.css', '.svg', '.png', '.ico', '.woff', '.woff2', '.ttf', '.xml'}
    pages = {}
    class Page(HTMLParser):
        def __init__(self):
            super().__init__(); self.ids = set(); self.links = []
        def handle_starttag(self, tag, attrs):
            attrs = dict(attrs)
            if attrs.get('id'): self.ids.add(attrs['id'])
            if tag == 'a' and attrs.get('name'): self.ids.add(attrs['name'])
            for key in ('href', 'src'):
                if attrs.get(key): self.links.append(attrs[key])
    for path in files:
        relative = path.relative_to(output).as_posix()
        if path.is_symlink() or any(part.startswith('.') for part in Path(relative).parts):
            raise ValueError(f'Forbidden output path: {relative}')
        if path.suffix not in allowed_extensions and relative not in {'search/search_index.json', 'build-manifest.json', 'sitemap.xml.gz'}:
            raise ValueError(f'Forbidden output type: {relative}')
        if path.suffix in {'.html', '.json', '.js'}:
            text = path.read_text(encoding='utf-8')
            if re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|glpat-[A-Za-z0-9_-]{20,}|AKIA[A-Z0-9]{16}', text):
                raise ValueError(f'Potential secret in output: {relative}')
            if path.suffix == '.html':
                page = Page(); page.feed(text); pages[path] = page
    file_set = set(files)
    @lru_cache(maxsize=None)
    def resolve_destination(path):
        destination = path.resolve()
        if destination / 'index.html' in file_set:
            destination /= 'index.html'
        return destination
    for path, page in pages.items():
        for target in page.links:
            url = urlsplit(target)
            if url.scheme or url.netloc:
                if url.scheme not in {'https', 'http', 'mailto', 'tel'}:
                    raise ValueError('Unsupported output URL scheme')
                continue
            destination = (output / unquote(url.path).lstrip('/')) if url.path.startswith('/') else (path.parent / unquote(url.path))
            if not url.path: destination = path
            destination = resolve_destination(destination)
            if not destination.is_relative_to(output) or destination not in file_set:
                raise ValueError(f'Broken output link in {path.relative_to(output)}: {target}')
            if url.fragment and destination in pages and unquote(url.fragment) not in pages[destination].ids:
                raise ValueError(f'Broken output anchor in {path.relative_to(output)}: {target}')
    return files


def direction(path):
    for prefix, value in [('overview/', 'overview'), ('technical/general/', 'general'),
                          ('technical/internal/', 'internal'), ('standards/', 'standards'),
                          ('reports/', 'overview')]:
        if path.startswith(prefix):
            return value
    if path == 'README.md':
        return 'overview'
    raise ValueError(f'Unclassified document: {path}')


def resolve_link(source, target, root, allowed, revision):
    url = urlsplit(target)
    if url.scheme or url.netloc:
        if url.scheme.lower() not in {'https', 'http', 'mailto'}:
            raise ValueError('Unsupported link scheme')
        return target
    if not url.path:
        return target
    root = Path(root).resolve()
    docs = root / 'docs'
    destination = (docs / source).parent / unquote(url.path)
    destination = destination.resolve()
    if not destination.is_relative_to(root):
        raise ValueError('Link leaves repository')
    if destination.is_relative_to(docs) and destination.suffix.lower() == '.md':
        return target
    relative = destination.relative_to(root).as_posix()
    if any(part.lower() in {'.git', '.secrets', '.env', '.ssh', '.aws'} for part in Path(relative).parts) or any(
        part.lower() in {'secrets', 'terraform.tfstate', 'terraform.tfstate.backup'}
        or part.lower().endswith(('.tfvars', '.tfstate', '.pem', '.key', '.env'))
        for part in Path(relative).parts
    ):
        raise ValueError('Sensitive source is forbidden')
    if relative not in allowed or not destination.exists():
        raise ValueError(f'External source is not approved: {relative}')
    kind = 'tree' if destination.is_dir() else 'blob'
    fragment = '#' + url.fragment if url.fragment else ''
    return f'{REPOSITORY_URL}/-/{kind}/{revision}/{quote(relative, safe="/")}{fragment}'
