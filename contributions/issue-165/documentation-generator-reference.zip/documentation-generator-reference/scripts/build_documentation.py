"""Build the private static documentation and its SHA-bound package in cloud CI."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import venv

from documentation_site import validate_output

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / 'web/docs-site'


def run(command, **kwargs):
    subprocess.run([str(item) for item in command], check=True, cwd=ROOT, **kwargs)


def build():
    def state():
        revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
        status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
        return revision, status
    initial = state()
    if initial[1]: raise RuntimeError('Package requires a clean committed CI checkout')
    environment = ROOT / 'tmp/docs-site-env'
    interpreter = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not interpreter.exists():
        venv.EnvBuilder(with_pip=True).create(environment)
    requirements = PROJECT / 'requirements.txt'
    digest = hashlib.sha256(requirements.read_bytes()).hexdigest()
    stamp = environment / 'requirements.sha256'
    if not stamp.exists() or stamp.read_text() != digest:
        run([interpreter, '-m', 'pip', 'install', '-r', requirements])
        stamp.write_text(digest)
    npm = shutil.which('npm.cmd' if os.name == 'nt' else 'npm')
    if not npm: raise RuntimeError('Node.js and npm are required')
    lock = hashlib.sha256((PROJECT / 'package-lock.json').read_bytes()).hexdigest()
    node_stamp = PROJECT / 'node_modules/.docs-lock.sha256'
    if not node_stamp.exists() or node_stamp.read_text() != lock:
        run([npm, '--prefix', PROJECT, 'ci', '--ignore-scripts', '--no-fund'])
        node_stamp.write_text(lock)
    asset_inputs = [PROJECT / name for name in ('client.js', 'site.css', 'vite.config.mjs', 'package.json', 'package-lock.json')]
    asset_inputs.append(PROJECT / 'layout.css')
    fingerprint = hashlib.sha256(b''.join(path.read_bytes() for path in asset_inputs) + subprocess.check_output(['node', '--version'])).hexdigest()
    asset_stamp = PROJECT / 'node_modules/.docs-assets.json'
    assets = PROJECT / 'theme/assets'
    def hashes():
        return {path.relative_to(assets).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in assets.rglob('*') if path.is_file()}
    previous = json.loads(asset_stamp.read_text()) if asset_stamp.exists() else {}
    if previous.get('input') != fingerprint or previous.get('files') != hashes() or not (assets / 'client.js').exists():
        run([npm, '--prefix', PROJECT, 'run', 'build'])
        asset_stamp.write_text(json.dumps({'input': fingerprint, 'files': hashes()}))
    run([interpreter, '-m', 'mkdocs', 'build', '--strict', '-f', PROJECT / 'mkdocs.yml'])
    output = PROJECT / 'site'
    files = validate_output(output)
    if state() != initial: raise RuntimeError('Git state changed during documentation build')
    revision = initial[0]
    manifest = {'source_sha': revision, 'pipeline_id': os.environ.get('CI_PIPELINE_ID'),
                'audience': 'internal-only', 'files': {file.relative_to(output).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest() for file in files}}
    (output / 'build-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    package = ROOT / 'tmp/documentation-site.tar.gz'
    with tarfile.open(package, 'w:gz') as archive:
        for file in validate_output(output): archive.add(file, arcname=file.relative_to(output).as_posix(), recursive=False)
    print(f'Private documentation package: {len(files)} files, source {revision}')
    return manifest


if __name__ == '__main__':
    build()
