# Modification notice

This is a sanitized reference-source contribution, not an installed skill or a deployed website. Original contributor material is offered under Apache-2.0 with explicit contributor authorization. Dependency licenses are unchanged.

The extraction removes source-project identity, documents, source allowlists and deployment configuration. It substitutes reserved example domains and generic branding, relocates shared layout CSS inside the renderer, makes the example redirect map optional, and removes a project-specific unit case. The remaining unit fixtures use temporary synthetic files.

Source layout and the four-direction taxonomy are retained as an example contract, not universal policy. No claim of independent cross-project adoption is made.
